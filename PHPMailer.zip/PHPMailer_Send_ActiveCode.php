<?php 
include("../config.php"); 

header('Content-Type: text/html; charset=utf-8');

  
$email = strip_tags(trim($_POST["Email"]));
$Avatar = strip_tags(trim($_POST["Avatar"]));
$UserName = strip_tags(trim($_POST["UserName"]));
$Active_Code = strip_tags(trim($_POST["Active_Code"]));

$imgAvatar = "https://novbook.net/test/android/Images/".$Avatar;

if ($email<>""){

 
require("PHPMailer/class.phpmailer.php");
			
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$mail->IsSMTP();
$mail->Host = "smtp.flockmail.com";
$mail->SMTPAuth = true;
$mail->Username = "info@novbook.net";
$mail->Password = "باسوورد الايميل";
$mail->From = "info@novbook.net";
$mail->SMTPSecure = "tls";
$mail->Port = 587;
$mail->FromName = "info@novbook.net";
$mail->AddAddress("{$email}");
$mail->WordWrap = 50;
$mail->IsHTML(true);
            
$mail->Subject = "رمز تفعيل التطبيق";
$mail->Body    = "
<table border='0' width='50%' cellspacing='0' cellpadding='0'>
<tr>
	<td align='center'>
	
<p>&nbsp;</p>
<table border='0' width='75%' cellspacing='1' style='border-collapse: collapse' bordercolor='#FF9900' bgcolor='#EFEFF4'>
<tr>
	<td colspan='2'>
	<p align='center'>
<img src='{$imgAvatar}' style='width: 150px; height: 150px; border-radius: 50%; border-color: #fff; border-width: 5px;'></td>
</tr>
<tr>
	<td align='center' width='100%' colspan='2'>
	<font size='4'>مرحباً <font color='orange'>{$UserName}<br>
	</font>  رمز تفعيل التطبيق   <br></font></td>
</tr>
<tr>	
	<td align='center' width='50%'><p><b><span lang='ar-om'><font color='red' , font size='6'>{$Active_Code}</font></span>
	</b></td>
</tr>

<br>
<br>
<tr><td align='center'>
<a href='https://www.yourSite'>مع تحيات فريق العمل</a>
<br></td></tr>

</td>
</tr>
</table>
</td>
</tr>
</table>

";


			if(!$mail->Send())
			{
			   $check = "Send_Error";   			
			   echo "Mailer Error: " . $mail->ErrorInfo;
			   exit;
			}else{
				$check = "Send_OK";       
			}

}else{
$check = "No_Email";    
}

  $json_re=array();
	array_push($json_re,array("success"=>$check));
    echo json_encode($json_re);   

?> 
  